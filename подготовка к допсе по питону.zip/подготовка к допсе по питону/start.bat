@echo off
py python_exam_tutor_v3_500_tasks.py
pause