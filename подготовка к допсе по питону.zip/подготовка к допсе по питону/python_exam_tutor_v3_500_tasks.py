# -*- coding: utf-8 -*-
"""
Python Exam Tutor
Отдельная учебная программа с графическим интерфейсом.
Запуск: python python_exam_tutor.py
Требуется только стандартный Python 3 с tkinter.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import json
import random
import textwrap
from pathlib import Path

APP_TITLE = "Python Exam Tutor"
PROGRESS_FILE = Path.home() / ".python_exam_tutor_progress.json"

LESSONS = [
    {
        "title": "0. Как вообще работает Python",
        "body": """
Представь, что программа — это набор очень точных команд.

Python читает код сверху вниз.

Например:

    name = "Alex"
    print(name)

Первая строка:
    name = "Alex"

означает:
создай переменную с именем name и положи в неё строку "Alex".

Вторая строка:
    print(name)

означает:
покажи значение переменной name на экране.

ВАЖНО:
знак = в Python — это НЕ математическое «равно».
Это операция присваивания.

То есть:

    x = 5

читается как:
«положи число 5 в переменную x».

Переменная — это просто имя, через которое мы обращаемся к значению.

Пример:

    dna = "ACGT"
    length = len(dna)

Теперь:
dna хранит "ACGT"
length хранит 4

Python различает типы данных:

    10          -> int, целое число
    10.5        -> float, дробное число
    "hello"     -> str, строка
    True        -> bool, истина
    False       -> bool, ложь
    [1, 2, 3]   -> list, список
    {"A": 1}    -> dict, словарь

Очень важно понимать тип значения, потому что разные типы умеют делать разные вещи.
""",
        "question": "Что делает строка x = 10 ?",
        "answers": ["кладет 10 в x", "присваивает 10 переменной x", "присваивает 10 x", "создает x со значением 10"],
        "hint": "Знак = здесь означает присваивание.",
        "explanation": "x становится переменной, которая ссылается на значение 10."
    },
    {
        "title": "1. Строки: str",
        "body": """
Строка — это текст.

Строки пишутся в кавычках:

    dna = "ACGT"
    name = "Alice"

В учебных материалах строки особенно важны, потому что последовательности ДНК удобно хранить именно как строки.

Например:

    dna = "ATGCCGTAA"

Каждый символ строки имеет номер — индекс.

Python начинает считать с НУЛЯ:

    символ:   A T G C
    индекс:   0 1 2 3

Поэтому:

    dna[0]

вернёт первый символ.

Пример:

    dna = "ACGT"

    dna[0]   -> "A"
    dna[1]   -> "C"
    dna[2]   -> "G"
    dna[3]   -> "T"

Можно считать с конца:

    dna[-1]

это последний символ.

Срез — это кусок строки:

    dna[start:stop]

Очень важное правило:

start ВКЛЮЧАЕТСЯ.
stop НЕ ВКЛЮЧАЕТСЯ.

Пример:

    dna = "AACCGGTT"
    dna[2:6]

Берутся индексы:
2, 3, 4, 5

Результат:
"CCGG"

Полезные функции и методы:

    len(dna)
    dna.upper()
    dna.lower()
    dna.count("G")
    dna.replace("A", "T")
    dna.strip()
    dna.split(",")

len(dna)
возвращает длину строки.

dna.count("G")
считает, сколько раз встретилась буква G.

strip()
часто нужен при чтении файлов, чтобы убрать перенос строки \\n.

Очень важная особенность:
строки НЕИЗМЕНЯЕМЫЕ.

Например:

    dna = "acgt"
    dna.upper()

сама переменная dna всё ещё содержит "acgt".

Если нужен новый результат:

    dna = dna.upper()
""",
        "question": "Что вернёт строка 'ABCDE'[2] ?",
        "answers": ["c", "'c'", "\"c\""],
        "hint": "Первый символ имеет индекс 0.",
        "explanation": "A=0, B=1, C=2. Поэтому ответ — C."
    },
    {
        "title": "2. Списки: list",
        "body": """
Список хранит несколько значений.

Пример:

    numbers = [10, 20, 30]

В списке три элемента.

Как и у строки, индексация начинается с 0:

    numbers[0] -> 10
    numbers[1] -> 20
    numbers[2] -> 30

Срезы работают почти так же:

    numbers[1:3]

вернёт элементы с индексами 1 и 2.

Главное отличие списка от строки:
СПИСОК МОЖНО ИЗМЕНЯТЬ.

Пример:

    numbers = [10, 20, 30]
    numbers[0] = 999

Теперь список:

    [999, 20, 30]

Добавление элемента:

    numbers.append(40)

append добавляет элемент В КОНЕЦ списка.

Удаление:

    numbers.pop()

удаляет последний элемент.

Можно удалить по индексу:

    numbers.pop(0)

Частая ошибка:

    result = numbers.append(40)

Так делать обычно не надо.

append меняет исходный список и возвращает None.

Правильно:

    numbers.append(40)

split() строки создаёт список:

    line = "10,20,30"
    parts = line.split(",")

parts будет:

    ["10", "20", "30"]

Обрати внимание:
это СТРОКИ, а не числа.

Если нужны числа:

    x = int(parts[0])
""",
        "question": "Как добавить элемент x в конец списка a?",
        "answers": ["a.append(x)", "append", "append()", ".append()"],
        "hint": "Метод называется append.",
        "explanation": "Правильная запись: a.append(x)."
    },
    {
        "title": "3. Цикл for",
        "body": """
Цикл нужен, когда одно действие надо повторить много раз.

Например, есть список:

    numbers = [1, 2, 3]

Можно написать:

    for number in numbers:
        print(number)

Python делает примерно следующее:

1. берёт первый элемент 1
2. кладёт его в переменную number
3. выполняет print(number)
4. берёт следующий элемент 2
5. снова выполняет тело цикла
6. затем 3

Отступы ОБЯЗАТЕЛЬНЫ.

Вот правильно:

    for number in numbers:
        print(number)

Вот неправильно:

    for number in numbers:
    print(number)

range() создаёт последовательность чисел.

    range(5)

это:

    0, 1, 2, 3, 4

Число 5 НЕ включается.

    range(2, 6)

это:

    2, 3, 4, 5

Пример:

    for i in range(5):
        print(i)

Накопление результата:

    squares = []

    for n in range(1, 6):
        squares.append(n ** 2)

После цикла:

    [1, 4, 9, 16, 25]

Очень важный шаблон:

    result = []

    for item in data:
        new_item = ...
        result.append(new_item)

Он часто встречается в задачах курса.
""",
        "question": "Какие числа переберёт range(3)? Напиши через запятую.",
        "answers": ["0,1,2", "0, 1, 2"],
        "hint": "range(3) начинается с 0, а 3 не включается.",
        "explanation": "Ответ: 0, 1, 2."
    },
    {
        "title": "4. Условия if / elif / else",
        "body": """
Условие позволяет выполнять код только в определённой ситуации.

Пример:

    age = 20

    if age >= 18:
        print("adult")

Выражение:

    age >= 18

даёт True или False.

Операторы сравнения:

    ==   равно
    !=   не равно
    >    больше
    <    меньше
    >=   больше или равно
    <=   меньше или равно

ОЧЕНЬ ЧАСТАЯ ОШИБКА:

    =

и

    ==

не одно и то же.

    x = 5

присваивает 5.

    x == 5

проверяет, равно ли x пяти.

Несколько вариантов:

    if score >= 90:
        print("A")
    elif score >= 60:
        print("pass")
    else:
        print("fail")

elif означает:
«иначе, если...»

else:
«во всех остальных случаях».

Логические операторы:

    and
    or
    not

and:
оба условия должны быть True.

    if age >= 18 and age <= 65:

or:
хотя бы одно условие True.

    if base == "A" or base == "T":

not:
переворачивает логическое значение.

Комбинация цикла и условия:

    for seq in sequences:
        if len(seq) > 10:
            print(seq)

То есть:
для каждой последовательности проверить длину.
""",
        "question": "Как проверить, что x равно 10?",
        "answers": ["x == 10", "=="],
        "hint": "Один знак = присваивает значение.",
        "explanation": "Сравнение на равенство записывается двумя знаками: x == 10."
    },
    {
        "title": "5. Работа с файлами",
        "body": """
Файл находится на диске.

Чтобы читать файл:

    f = open("input.txt")
    content = f.read()
    f.close()

open() открывает файл.
read() получает содержимое.
close() закрывает файл.

Удобнее:

    with open("input.txt") as f:
        content = f.read()

with автоматически закроет файл.

Режимы:

    "r" -> read
    "w" -> write
    "a" -> append

r:
читать.

w:
записывать ЗАНОВО.

ВАЖНО:
режим w стирает старое содержимое файла.

a:
дописать в конец.

Чтение всего файла:

    content = f.read()

Чтение как списка строк:

    lines = f.readlines()

Или можно сразу перебирать файл:

    with open("input.txt") as f:
        for line in f:
            print(line)

Очень часто строка файла заканчивается символом переноса:

    \\n

Поэтому часто делают:

    line = line.strip()

Запись:

    with open("output.txt", "w") as f:
        f.write("Hello\\n")

\\n означает перенос строки.

FASTA:

    >sequence_name
    ACTGACTGACTG

Строка с > — заголовок.
Остальные строки — последовательность.
""",
        "question": "Какой режим открывает файл для записи с перезаписью?",
        "answers": ["w", "\"w\"", "'w'"],
        "hint": "write.",
        "explanation": "Режим w означает write и перезаписывает содержимое."
    },
    {
        "title": "6. Функции",
        "body": """
Функция — это кусок программы, которому дали имя.

Пример:

    def square(x):
        return x ** 2

Здесь:

def
говорит Python:
«сейчас создаём функцию».

square
имя функции.

x
параметр функции.

return
возвращает результат.

Вызов:

    result = square(5)

Во время вызова:
x получает значение 5.

Затем:

    x ** 2

это 25.

return возвращает 25.

Поэтому result становится 25.

ВАЖНО:
print и return — разные вещи.

    print(x)

только показывает значение на экране.

    return x

возвращает значение из функции в программу.

Например:

    def add(a, b):
        return a + b

    total = add(3, 4)

Теперь total = 7.

Если функция не выполняет return,
она возвращает None.

Пример функции для GC-content:

    def gc_content(dna):
        gc = dna.count("G") + dna.count("C")
        return gc / len(dna)

Вызов:

    value = gc_content("ACGCGT")

Очень полезно сначала написать алгоритм словами:

1. посчитать G
2. посчитать C
3. сложить
4. разделить на длину

И только потом писать код.
""",
        "question": "Какое слово возвращает значение из функции?",
        "answers": ["return"],
        "hint": "Это не print.",
        "explanation": "return возвращает значение вызывающему коду."
    },
    {
        "title": "7. Словари и кортежи",
        "body": """
Словарь хранит пары:

    ключ -> значение

Пример:

    person = {
        "name": "Alex",
        "age": 20
    }

Получение значения:

    person["name"]

вернёт:

    "Alex"

У списка мы используем индекс:

    a[0]

У словаря используем ключ:

    person["name"]

Добавление:

    person["city"] = "Amsterdam"

Изменение:

    person["age"] = 21

Перебор:

    for key in person:
        print(key, person[key])

Очень удобно:

    for key, value in person.items():
        print(key, value)

Методы:

    .keys()
    .values()
    .items()

Кортеж:

    point = (10, 20)

Кортеж похож на список,
но обычно используется как фиксированная группа значений.

Можно распаковать:

    x, y = point

Теперь:

    x = 10
    y = 20

Когда пишем:

    for key, value in dictionary.items():

мы тоже используем распаковку пары.
""",
        "question": "Как получить пары ключ-значение словаря d?",
        "answers": ["d.items()", "items()", ".items()", "items"],
        "hint": "Метод называется items.",
        "explanation": "Используется d.items()."
    },
    {
        "title": "8. Типовые задачи с DNA",
        "body": """
GC-content.

Пусть:

    dna = "ACGCGT"

Количество G:

    dna.count("G")

Количество C:

    dna.count("C")

Общее GC:

    gc = dna.count("G") + dna.count("C")

Доля:

    gc / len(dna)

Процент:

    gc / len(dna) * 100


Удаление адаптера.

Если первые 14 символов — адаптер:

    cleaned = sequence[14:]

Почему [14:]?

Потому что это означает:
взять строку с индекса 14 до конца.


Обработка файла:

    with open("input.txt") as inp, open("output.txt", "w") as out:
        for line in inp:
            sequence = line.strip()
            cleaned = sequence[14:]
            out.write(cleaned + "\\n")


Координаты экзонов.

Если строка:

    "10,20"

можно сделать:

    start_text, stop_text = line.strip().split(",")

Теперь:

    start_text == "10"
    stop_text == "20"

Но это строки.

Нужно:

    start = int(start_text)
    stop = int(stop_text)

После этого можно делать срез:

    exon = dna[start:stop]

Будь внимателен:
если условие использует биологическую систему координат,
она может отличаться от индексации Python.
На экзамене надо смотреть формулировку задания.
""",
        "question": "Как взять всё в строке seq после первых 14 символов?",
        "answers": ["seq[14:]", "[14:]"],
        "hint": "Срез без правой границы.",
        "explanation": "seq[14:] берёт символы от индекса 14 до конца."
    },
    {
        "title": "9. Multi-FASTA",
        "body": """
Multi-FASTA может содержать много записей:

    >seq1
    ACGT
    ACGT
    >seq2
    TTTT
    CCCC

Проблема:
одна последовательность может быть разбита на несколько строк.

Поэтому нельзя просто считать:
«следующая строка после > — вся последовательность».

Удобный алгоритм:

    current_name = None
    current_sequence = ""

Идём по строкам.

Если строка начинается с >:
началась новая запись.

Если у нас уже была предыдущая запись:
сохраняем её.

Иначе:
добавляем строку к current_sequence.

Пример:

    names = []
    sequences = []

    current_name = None
    current_sequence = ""

    with open("input.fasta") as f:
        for raw_line in f:
            line = raw_line.strip()

            if line.startswith(">"):
                if current_name is not None:
                    names.append(current_name)
                    sequences.append(current_sequence)

                current_name = line[1:]
                current_sequence = ""

            else:
                current_sequence += line

После цикла надо не забыть сохранить ПОСЛЕДНЮЮ запись:

    if current_name is not None:
        names.append(current_name)
        sequences.append(current_sequence)

Почему?

Потому что последняя запись не встретит после себя новый символ >,
который заставил бы нас сохранить её внутри цикла.
""",
        "question": "Как проверить, начинается ли строка line с символа > ?",
        "answers": ['line.startswith(">")', "startswith", "startswith()"],
        "hint": "У строк есть метод startswith.",
        "explanation": 'Используется line.startswith(">").'
    },
]


def make_task(category, question, answer, hint1, hint2, hint3, explanation, accepted=None):
    if accepted is None:
        accepted = [answer]
    return {
        "category": category,
        "question": question,
        "answer": answer,
        "accepted": accepted,
        "hint1": hint1,
        "hint2": hint2,
        "hint3": hint3,
        "explanation": explanation,
    }

def build_practice_bank():
    tasks = []
    random.seed(42)

    # ---------------------------------------------------------
    # 0. ОСНОВЫ PYTHON — 50
    # ---------------------------------------------------------
    contexts = [
        ("age", 18), ("score", 75), ("temperature", 21), ("count", 4),
        ("length", 120), ("year", 2026), ("price", 9), ("attempts", 3),
        ("students", 24), ("genes", 11)
    ]
    for i in range(10):
        var, value = contexts[i]
        tasks.append(make_task(
            "0. Основы Python",
            f"Создай переменную {var} и положи в неё число {value}.",
            f"{var} = {value}",
            "Нужно присвоить значение переменной.",
            "Слева пишется имя переменной, затем =, затем значение.",
            f"{var} = {value}",
            "Оператор = выполняет присваивание."
        ))
    vals = [5, 12, 3.5, "ACGT", "hello", True, 0, -4, 99, "DNA"]
    types = ["int","int","float","str","str","bool","int","int","int","str"]
    for v,t in zip(vals,types):
        shown = repr(v)
        tasks.append(make_task(
            "0. Основы Python",
            f"Какой тип данных у значения {shown}? Ответь именем типа.",
            t,
            "Определи, что это: целое число, дробь, строка или логическое значение.",
            "Целые числа -> int; дробные -> float; текст -> str; True/False -> bool.",
            t,
            f"Значение {shown} имеет тип {t}."
        ))
    exprs = [
        ("2 + 3", "5"), ("10 - 4", "6"), ("3 * 4", "12"), ("8 / 2", "4.0"),
        ("2 ** 3", "8"), ("9 // 2", "4"), ("9 % 2", "1"), ("5 + 2 * 3", "11"),
        ("(5 + 2) * 3", "21"), ("10 / 4", "2.5")
    ]
    for expr, ans in exprs:
        tasks.append(make_task(
            "0. Основы Python",
            f"Какое значение получится у выражения: {expr}",
            ans,
            "Вычисли выражение по правилам арифметики Python.",
            "Помни: ** — степень, // — целая часть деления, % — остаток.",
            ans,
            f"Результат выражения {expr} равен {ans}."
        ))
    conv = [
        ('int("12")',"12"), ('float("2.5")',"2.5"), ('str(15)',"15"),
        ('len("ACGT")',"4"), ('len([1,2,3])',"3"),
        ('bool(1)',"True"), ('bool(0)',"False"), ('int(3.9)',"3"),
        ('float(4)',"4.0"), ('str(True)',"True")
    ]
    for expr, ans in conv:
        tasks.append(make_task(
            "0. Основы Python",
            f"Что вернёт выражение {expr}? Напиши только значение.",
            ans,
            "Посмотри, что делает вызываемая функция.",
            "int -> целое, float -> дробное, str -> строковое представление, len -> длина.",
            ans,
            f"Результат: {ans}."
        ))
    errors = [
        ("x == 5", "сравнение"), ("x = 5", "присваивание"),
        ("print(x)", "вывод"), ("len(x)", "длина"),
        ("int(x)", "преобразование в int"), ("str(x)", "преобразование в str"),
        ("# hello", "комментарий"), ("True", "логическое значение"),
        ("None", "отсутствие значения"), ("input()", "ввод")
    ]
    for code_piece, meaning in errors:
        tasks.append(make_task(
            "0. Основы Python",
            f"Что делает/означает конструкция {code_piece}? Ответ: {meaning}",
            meaning,
            "Определи роль конструкции, а не вычисляй результат.",
            f"Подумай о базовом назначении: {meaning}.",
            meaning,
            f"{code_piece} — это {meaning}."
        ))

    # ---------------------------------------------------------
    # 1. СТРОКИ — 50
    # ---------------------------------------------------------
    strings = ["ABCDE","ACGTAC","PYTHON","GENOME","banana","ATGCCGTAA","hello","sequence","AACCGGTT","bioinfo"]
    for s in strings:
        idx = 2 if len(s) > 2 else 0
        tasks.append(make_task(
            "1. Строки",
            f"Дана строка s = {s!r}. Что вернёт s[{idx}]?",
            s[idx],
            "Нужно взять символ по индексу.",
            "Python считает индексы с нуля.",
            repr(s[idx]),
            f"Символ с индексом {idx}: {s[idx]}."
        ))
    for s in strings:
        tasks.append(make_task(
            "1. Строки",
            f"Дана строка s = {s!r}. Как получить её последний символ?",
            "s[-1]",
            "Используй отрицательный индекс.",
            "-1 означает последний элемент.",
            "s[-1]",
            "s[-1] обращается к последнему символу."
        ))
    slices = [
        ("AACCGGTT",2,6), ("PYTHON",1,4), ("GENOME",0,3), ("sequence",3,7),
        ("ABCDEFG",2,5), ("ATGCCG",1,5), ("bioinfo",0,3), ("banana",1,5),
        ("ACGTACGT",4,8), ("HELLOWORLD",5,10)
    ]
    for s,a,b in slices:
        ans = s[a:b]
        tasks.append(make_task(
            "1. Строки",
            f"Что вернёт {s!r}[{a}:{b}]?",
            ans,
            "Это срез строки.",
            f"Берутся индексы от {a} до {b-1}; правая граница {b} не включается.",
            repr(ans),
            f"Результат среза: {ans}."
        ))
    methods = [
        ('dna.upper()', 'ACGT', 'dna = "acgt"'),
        ('dna.lower()', 'acgt', 'dna = "ACGT"'),
        ('dna.count("G")', '2', 'dna = "AGGT"'),
        ('dna.replace("A","T")', 'TCGT', 'dna = "ACGT"'),
        ('text.strip()', 'hello', 'text = "  hello  "'),
        ('text.split(",")', "['A', 'B', 'C']", 'text = "A,B,C"'),
        ('len(dna)', '6', 'dna = "ACGTAA"'),
        ('dna.startswith("ATG")', 'True', 'dna = "ATGCCC"'),
        ('"A" in dna', 'True', 'dna = "CGAT"'),
        ('dna + "TT"', 'ACGTTT', 'dna = "ACGT"')
    ]
    for expr,ans,setup in methods:
        tasks.append(make_task(
            "1. Строки",
            f"{setup}. Что вернёт {expr}?",
            ans,
            "Вспомни назначение строкового метода/операции.",
            f"Сначала используй значение из {setup}.",
            ans,
            f"Результат: {ans}."
        ))
    dna_cases = ["ACGT","GGCC","AAAA","ATGCATGC","GCGTTA","CCCG","TATA","AGCTAGCT","GATTACA","CGCGCG"]
    for dna in dna_cases:
        gc = dna.count("G")+dna.count("C")
        tasks.append(make_task(
            "1. Строки",
            f"Для dna = {dna!r} напиши выражение, которое считает число G и C вместе.",
            'dna.count("G") + dna.count("C")',
            "Нужно посчитать два символа и сложить.",
            "Используй .count('G') и .count('C').",
            'dna.count("G") + dna.count("C")',
            f"В этой конкретной строке GC-символов {gc}."
        ))

    # ---------------------------------------------------------
    # 2. СПИСКИ — 50
    # ---------------------------------------------------------
    arrays = [[1,2,3],[10,20,30],["A","C","G"],[5,8,13],["cat","dog"],[0,1],[9,8,7,6],[100],["DNA","RNA"],[2,4,6,8]]
    for arr in arrays:
        tasks.append(make_task(
            "2. Списки",
            f"Дан список a = {arr!r}. Что вернёт a[0]?",
            str(arr[0]),
            "Возьми первый элемент списка.",
            "Первый индекс — 0.",
            repr(arr[0]),
            f"Первый элемент: {arr[0]}."
        ))
    for arr in arrays:
        x = "X" if isinstance(arr[0], str) else 99
        tasks.append(make_task(
            "2. Списки",
            f"Дан список a = {arr!r}. Напиши команду добавления {x!r} в конец.",
            f"a.append({x!r})",
            "Нужен метод добавления одного элемента.",
            "Метод называется append.",
            f"a.append({x!r})",
            "append добавляет элемент в конец списка."
        ))
    for arr in arrays:
        tasks.append(make_task(
            "2. Списки",
            f"Дан список a = {arr!r}. Как удалить и получить последний элемент?",
            "a.pop()",
            "Нужен метод, который удаляет элемент и возвращает его.",
            "Без аргумента pop работает с последним элементом.",
            "a.pop()",
            "a.pop() удаляет последний элемент и возвращает его."
        ))
    splits = ["1,2,3","A,C,G,T","cat dog bird","red;green;blue","10|20|30","AA,BB","x:y:z","one two","G,C","alpha-beta"]
    seps = [",",","," ",";","|",",",":"," ",",","-"]
    for s,sep in zip(splits,seps):
        ans = s.split(sep)
        tasks.append(make_task(
            "2. Списки",
            f"Как превратить строку text = {s!r} в список частей, разделяя по {sep!r}?",
            f"text.split({sep!r})",
            "Используй метод строки split.",
            "В split передаётся символ-разделитель.",
            f"text.split({sep!r})",
            f"Результат будет {ans!r}."
        ))
    for arr in arrays:
        tasks.append(make_task(
            "2. Списки",
            f"Как получить количество элементов списка a = {arr!r}?",
            "len(a)",
            "Для длины последовательностей используется одна встроенная функция.",
            "Эта же функция работает со строками.",
            "len(a)",
            f"В списке {len(arr)} элемент(ов)."
        ))

    # ---------------------------------------------------------
    # 3. ЦИКЛЫ — 50
    # ---------------------------------------------------------
    names = ["numbers","genes","sequences","scores","items","names","bases","lengths","values","records"]
    for n in names:
        tasks.append(make_task(
            "3. Циклы",
            f"Напиши цикл, который печатает каждый элемент списка {n}.",
            f"for item in {n}:\n    print(item)",
            "Нужно перебрать список циклом for.",
            f"Структура: for item in {n}: затем print(item) с отступом.",
            f"for item in {n}:\n    print(item)",
            "На каждой итерации item получает очередной элемент."
        ))
    ranges = [(5,), (3,), (1,5), (2,7), (10,), (5,9), (0,4), (3,8), (1,4), (6,10)]
    for r in ranges:
        call = "range(" + ", ".join(map(str,r)) + ")"
        seq = list(range(*r))
        tasks.append(make_task(
            "3. Циклы",
            f"Какие числа даёт {call}? Ответь через запятую.",
            ",".join(map(str,seq)),
            "Вспомни, что правая граница range не включается.",
            f"Начало/конец задаются аргументами {r}.",
            ", ".join(map(str,seq)),
            f"{call} -> {seq}."
        ))
    for stop in range(3,13):
        tasks.append(make_task(
            "3. Циклы",
            f"Создай список квадратов чисел от 1 до {stop} включительно в переменной squares.",
            f"squares = []\nfor n in range(1, {stop+1}):\n    squares.append(n ** 2)",
            "Создай пустой список и постепенно добавляй результаты.",
            f"Нужен range(1, {stop+1}), оператор ** 2 и append.",
            f"squares = []\nfor n in range(1, {stop+1}):\n    squares.append(n ** 2)",
            "Это типичный шаблон накопления результата в цикле."
        ))
    for cutoff in range(3,13):
        tasks.append(make_task(
            "3. Циклы",
            f"Есть sequences. Напиши цикл, который печатает только последовательности длиной больше {cutoff}.",
            f"for seq in sequences:\n    if len(seq) > {cutoff}:\n        print(seq)",
            "Нужно совместить цикл и условие.",
            f"Сначала for seq in sequences, затем внутри if len(seq) > {cutoff}.",
            f"for seq in sequences:\n    if len(seq) > {cutoff}:\n        print(seq)",
            "Для каждого элемента отдельно проверяется условие длины."
        ))
    for adapter in range(5,15):
        tasks.append(make_task(
            "3. Циклы",
            f"Есть список sequences. Создай cleaned, где у каждой строки удалены первые {adapter} символов.",
            f"cleaned = []\nfor seq in sequences:\n    cleaned.append(seq[{adapter}:])",
            "Нужно создать новый список и обработать каждый элемент.",
            f"Для каждой seq возьми срез seq[{adapter}:] и добавь его в cleaned.",
            f"cleaned = []\nfor seq in sequences:\n    cleaned.append(seq[{adapter}:])",
            "Так цикл преобразует каждый элемент и сохраняет результаты."
        ))

    # ---------------------------------------------------------
    # 4. УСЛОВИЯ — 50
    # ---------------------------------------------------------
    comps = [("x",10,">"),("score",60,">="),("age",18,">="),("temp",0,"<"),("n",5,"!="),
             ("length",100,">"),("gc",50,">="),("count",0,"=="),("year",2020,">="),("value",1,"<=")]
    for var,val,op in comps:
        tasks.append(make_task(
            "4. Условия",
            f"Напиши условие if: если {var} {op} {val}, вывести 'yes'.",
            f"if {var} {op} {val}:\n    print(\"yes\")",
            "Нужен if с данным оператором сравнения.",
            "После условия ставится двоеточие, тело — с отступом.",
            f"if {var} {op} {val}:\n    print(\"yes\")",
            "Условный блок выполняется только при True."
        ))
    bounds = [(1,10),(0,100),(18,65),(5,20),(2,8),(10,50),(3,9),(100,200),(30,70),(4,12)]
    for lo,hi in bounds:
        tasks.append(make_task(
            "4. Условия",
            f"Напиши логическое выражение: x находится от {lo} до {hi} включительно.",
            f"x >= {lo} and x <= {hi}",
            "Нужно одновременно проверить две границы.",
            "Свяжи два сравнения оператором and.",
            f"x >= {lo} and x <= {hi}",
            "and требует истинности обоих условий."
        ))
    values = [-3,0,5,12,100,-1,7,0,42,-20]
    for x in values:
        ans = "positive" if x>0 else "zero" if x==0 else "negative"
        tasks.append(make_task(
            "4. Условия",
            f"Для x = {x}: что напечатает код if x>0: positive; elif x==0: zero; else: negative?",
            ans,
            "Проверь условия сверху вниз.",
            "Сначала x > 0, затем x == 0, иначе отрицательное.",
            ans,
            f"Ответ: {ans}."
        ))
    bases = ["A","C","G","T","N","A","T","G","C","N"]
    for b in bases:
        ans = "purine" if b in ("A","G") else "other"
        tasks.append(make_task(
            "4. Условия",
            f"base = {b!r}. Что выведет: if base == 'A' or base == 'G': 'purine', иначе 'other'?",
            ans,
            "Оператор or требует истинности хотя бы одного сравнения.",
            "Проверь, равна ли base A или G.",
            ans,
            f"Результат: {ans}."
        ))
    for t in range(10):
        threshold = 20+t
        tasks.append(make_task(
            "4. Условия",
            f"Есть seq. Напиши if/else: если len(seq) >= {threshold}, print('long'), иначе print('short').",
            f"if len(seq) >= {threshold}:\n    print(\"long\")\nelse:\n    print(\"short\")",
            "Нужны две ветки: if и else.",
            f"Условие: len(seq) >= {threshold}.",
            f"if len(seq) >= {threshold}:\n    print(\"long\")\nelse:\n    print(\"short\")",
            "else выполняется, если условие if ложно."
        ))

    # ---------------------------------------------------------
    # 5. ФАЙЛЫ — 50
    # ---------------------------------------------------------
    filenames = ["input.txt","dna.txt","genes.txt","scores.txt","data.txt","seq.txt","notes.txt","sample.txt","reads.txt","records.txt"]
    for fn in filenames:
        tasks.append(make_task(
            "5. Файлы",
            f"Открой {fn!r} через with и прочитай всё содержимое в content.",
            f"with open({fn!r}) as f:\n    content = f.read()",
            "Используй with open и read().",
            "Файл можно открыть без явного 'r', потому что это режим по умолчанию.",
            f"with open({fn!r}) as f:\n    content = f.read()",
            "with автоматически закрывает файл."
        ))
    for fn in filenames:
        tasks.append(make_task(
            "5. Файлы",
            f"Открой {fn!r} для записи и запиши строку 'Hello'.",
            f"with open({fn!r}, \"w\") as f:\n    f.write(\"Hello\")",
            "Для перезаписи используется режим w.",
            "Внутри блока вызывается f.write(...).",
            f"with open({fn!r}, \"w\") as f:\n    f.write(\"Hello\")",
            "Режим w перезаписывает файл."
        ))
    for fn in filenames:
        tasks.append(make_task(
            "5. Файлы",
            f"Пройди по строкам файла {fn!r} и напечатай каждую строку без \\n по краям.",
            f"with open({fn!r}) as f:\n    for line in f:\n        print(line.strip())",
            "Файл можно перебирать циклом.",
            "На каждой строке вызови strip().",
            f"with open({fn!r}) as f:\n    for line in f:\n        print(line.strip())",
            "strip убирает перенос строки и пробелы по краям."
        ))
    for n in range(5,15):
        tasks.append(make_task(
            "5. Файлы",
            f"В каждой строке input.txt первые {n} символов — адаптер. Запиши очищенные строки в output.txt.",
            f"with open(\"input.txt\") as inp, open(\"output.txt\", \"w\") as out:\n    for line in inp:\n        sequence = line.strip()\n        out.write(sequence[{n}:] + \"\\n\")",
            "Нужно одновременно читать один файл и писать другой.",
            f"Для каждой строки: strip(), затем срез [{n}:], затем write(... + '\\n').",
            f"with open(\"input.txt\") as inp, open(\"output.txt\", \"w\") as out:\n    for line in inp:\n        sequence = line.strip()\n        out.write(sequence[{n}:] + \"\\n\")",
            "Это типовая схема обработки файла построчно."
        ))
    modes = [("r","чтение"),("w","запись с перезаписью"),("a","добавление в конец"),
             ("r","чтение"),("w","запись с перезаписью"),("a","добавление в конец"),
             ("r","чтение"),("w","запись с перезаписью"),("a","добавление в конец"),("r","чтение")]
    for mode,meaning in modes:
        tasks.append(make_task(
            "5. Файлы",
            f"Что означает режим файла {mode!r}?",
            meaning,
            "Вспомни базовые режимы open().",
            "r=read, w=write, a=append.",
            meaning,
            f"{mode} означает {meaning}."
        ))

    # ---------------------------------------------------------
    # 6. ФУНКЦИИ — 50
    # ---------------------------------------------------------
    funcs = [("double","x * 2"),("square","x ** 2"),("cube","x ** 3"),("negate","-x"),
             ("increment","x + 1"),("decrement","x - 1"),("half","x / 2"),("absolute","abs(x)"),
             ("as_text","str(x)"),("length","len(x)")]
    for name,expr in funcs:
        tasks.append(make_task(
            "6. Функции",
            f"Напиши функцию {name}(x), которая возвращает {expr}.",
            f"def {name}(x):\n    return {expr}",
            "Определи функцию с одним параметром и используй return.",
            f"Структура: def {name}(x): затем return ...",
            f"def {name}(x):\n    return {expr}",
            "return отдаёт результат вызывающему коду."
        ))
    for i in range(10):
        tasks.append(make_task(
            "6. Функции",
            f"Напиши функцию add_{i}(x), которая возвращает x + {i}.",
            f"def add_{i}(x):\n    return x + {i}",
            "Параметр x должен участвовать в выражении.",
            f"Верни x + {i}.",
            f"def add_{i}(x):\n    return x + {i}",
            "Функция возвращает новое значение."
        ))
    dna_funcs = [
        ("count_g",'dna.count("G")'),("count_c",'dna.count("C")'),("dna_length","len(dna)"),
        ("first_base","dna[0]"),("last_base","dna[-1]"),("uppercase","dna.upper()"),
        ("without_first","dna[1:]"),("first_three","dna[:3]"),
        ("has_atg",'dna.startswith("ATG")'),("gc_count",'dna.count("G") + dna.count("C")')
    ]
    for name,expr in dna_funcs:
        tasks.append(make_task(
            "6. Функции",
            f"Напиши функцию {name}(dna), которая возвращает результат выражения {expr}.",
            f"def {name}(dna):\n    return {expr}",
            "Нужна маленькая функция-обёртка вокруг одного выражения.",
            f"После def {name}(dna): используй return.",
            f"def {name}(dna):\n    return {expr}",
            "Функция получает dna через параметр."
        ))
    for denom in range(1,11):
        tasks.append(make_task(
            "6. Функции",
            f"Напиши функцию fraction(x), которая возвращает x / {denom}.",
            f"def fraction(x):\n    return x / {denom}",
            "Используй параметр x и return.",
            f"Верни выражение x / {denom}.",
            f"def fraction(x):\n    return x / {denom}",
            "return завершает функцию и возвращает результат."
        ))
    calls = [(2,4),(3,9),(5,25),(7,49),(10,100),(1,1),(4,16),(6,36),(8,64),(9,81)]
    for x,ans in calls:
        tasks.append(make_task(
            "6. Функции",
            f"Дана функция def square(x): return x ** 2. Что вернёт square({x})?",
            str(ans),
            "Подставь аргумент вместо параметра x.",
            f"{x} ** 2.",
            str(ans),
            f"square({x}) возвращает {ans}."
        ))

    # ---------------------------------------------------------
    # 7. СЛОВАРИ И КОРТЕЖИ — 50
    # ---------------------------------------------------------
    pairs = [("name","Alex"),("age",20),("city","Rome"),("A",3),("G",5),("score",88),("gene","BRCA1"),("x",10),("y",20),("status","ok")]
    for k,v in pairs:
        d = {k:v}
        tasks.append(make_task(
            "7. Словари и кортежи",
            f"Дан словарь d = {d!r}. Как получить значение ключа {k!r}?",
            f"d[{k!r}]",
            "Словарь индексируется не числом, а ключом.",
            f"Используй квадратные скобки с ключом {k!r}.",
            f"d[{k!r}]",
            f"Так получаем значение {v!r}."
        ))
    for k,v in pairs:
        tasks.append(make_task(
            "7. Словари и кортежи",
            f"Добавь в словарь d пару {k!r}: {v!r}.",
            f"d[{k!r}] = {v!r}",
            "Присвой значение по ключу.",
            "Слева d[ключ], справа значение.",
            f"d[{k!r}] = {v!r}",
            "Так можно и добавить новый ключ, и изменить существующий."
        ))
    methods = [("d.keys()","ключи"),("d.values()","значения"),("d.items()","пары ключ-значение"),
               ("len(d)","количество пар"),("'A' in d","проверка наличия ключа"),
               ("d.get('A')","получение значения по ключу"),("d.keys()","ключи"),
               ("d.values()","значения"),("d.items()","пары ключ-значение"),("len(d)","количество пар")]
    for expr,meaning in methods:
        tasks.append(make_task(
            "7. Словари и кортежи",
            f"Что возвращает/проверяет выражение {expr}?",
            meaning,
            "Вспомни методы словаря.",
            f"Назначение: {meaning}.",
            meaning,
            f"{expr}: {meaning}."
        ))
    tuples = [(1,2),("A","T"),(10,20),(3,4),("name",99),("G",5),(0,1),(7,8),("x","y"),(100,200)]
    for a,b in tuples:
        tasks.append(make_task(
            "7. Словари и кортежи",
            f"Есть tuple pair = {(a,b)!r}. Напиши распаковку в переменные x и y.",
            "x, y = pair",
            "Два элемента можно сразу разложить по двум переменным.",
            "Слева два имени через запятую, справа pair.",
            "x, y = pair",
            f"После распаковки x={a!r}, y={b!r}."
        ))
    for base in ["A","C","G","T","N","A","G","C","T","N"]:
        tasks.append(make_task(
            "7. Словари и кортежи",
            f"Есть словарь counts. Увеличь значение ключа {base!r} на 1.",
            f"counts[{base!r}] = counts[{base!r}] + 1",
            "Нужно прочитать старое значение, прибавить 1 и записать обратно.",
            f"Используй counts[{base!r}] по обе стороны присваивания.",
            f"counts[{base!r}] = counts[{base!r}] + 1",
            "Это стандартный шаблон счётчика."
        ))

    # ---------------------------------------------------------
    # 8. DNA / БИОИНФОРМАТИКА — 50
    # ---------------------------------------------------------
    dnas = ["ACGT","GGCC","AAAA","ATGCATGC","GCGTTA","CCCG","TATA","AGCTAGCT","GATTACA","CGCGCG"]
    for dna in dnas:
        pct=(dna.count("G")+dna.count("C"))/len(dna)*100
        tasks.append(make_task(
            "8. DNA и последовательности",
            f"dna = {dna!r}. Посчитай GC-процент выражением Python.",
            '(dna.count("G") + dna.count("C")) / len(dna) * 100',
            "GC-процент = количество G+C / общая длина * 100.",
            "Используй count дважды и len один раз.",
            '(dna.count("G") + dna.count("C")) / len(dna) * 100',
            f"Для этой строки GC% = {pct:g}."
        ))
    for n in range(5,15):
        tasks.append(make_task(
            "8. DNA и последовательности",
            f"В sequence первые {n} нуклеотидов — адаптер. Получи очищенную строку.",
            f"sequence[{n}:]",
            "Используй срез от позиции после адаптера до конца.",
            f"Срез начинается с индекса {n}.",
            f"sequence[{n}:]",
            "Срез без stop берёт всё до конца."
        ))
    motifs = ["ATG","TAA","TAG","TGA","AAA","GGG","CCC","ACG","GTA","CAT"]
    for m in motifs:
        tasks.append(make_task(
            "8. DNA и последовательности",
            f"Напиши выражение, проверяющее, содержится ли мотив {m!r} в строке dna.",
            f"{m!r} in dna",
            "Для проверки наличия подстроки можно использовать оператор in.",
            f"Слева мотив {m!r}, затем in, затем dna.",
            f"{m!r} in dna",
            "Оператор in возвращает True или False."
        ))
    starts = ["ATG","AAA","GGG","CCC","TATA","GCG","ACT","TTT","CGA","GAT"]
    for m in starts:
        tasks.append(make_task(
            "8. DNA и последовательности",
            f"Проверь, начинается ли dna с {m!r}.",
            f"dna.startswith({m!r})",
            "У строки есть специальный метод проверки начала.",
            "Метод называется startswith.",
            f"dna.startswith({m!r})",
            "startswith возвращает логическое значение."
        ))
    for base in ["A","C","G","T","A","G","C","T","G","A"]:
        tasks.append(make_task(
            "8. DNA и последовательности",
            f"Напиши выражение, считающее количество {base} в dna.",
            f'dna.count("{base}")',
            "Используй строковый метод count.",
            f"Передай символ {base!r} в count.",
            f'dna.count("{base}")',
            "count считает число вхождений."
        ))

    # ---------------------------------------------------------
    # 9. FASTA / MULTI-FASTA — 50
    # ---------------------------------------------------------
    headers = ["seq1","geneA","sample_01","human","mouse","BRCA1","read42","contig7","proteinX","record10"]
    for h in headers:
        tasks.append(make_task(
            "9. FASTA и Multi-FASTA",
            f"Сформируй строку FASTA-заголовка для имени header = {h!r}.",
            '">" + header',
            "FASTA-заголовок начинается с символа >.",
            "Соедини строку '>' и переменную header.",
            '">" + header',
            f"Результат будет >{h}."
        ))
    for h in headers:
        tasks.append(make_task(
            "9. FASTA и Multi-FASTA",
            f"Есть line с FASTA-заголовком. Как получить имя без первого символа >?",
            "line[1:]",
            "Нужно удалить первый символ строки.",
            "Срез с индекса 1 до конца.",
            "line[1:]",
            "line[1:] отбрасывает символ с индексом 0."
        ))
    for i in range(10):
        tasks.append(make_task(
            "9. FASTA и Multi-FASTA",
            "Напиши условие, проверяющее, что line является FASTA-заголовком.",
            'line.startswith(">")',
            "Заголовок FASTA начинается с >.",
            "Используй строковый метод startswith.",
            'line.startswith(">")',
            "startswith('>') вернёт True для заголовка."
        ))
    for i in range(10):
        tasks.append(make_task(
            "9. FASTA и Multi-FASTA",
            "В Multi-FASTA текущая последовательность хранится в current_sequence. Добавь к ней строку line.",
            "current_sequence += line",
            "Нужно не заменить накопленную строку, а дописать новую часть.",
            "Можно использовать сокращённое присваивание +=.",
            "current_sequence += line",
            "Так последовательность собирается из нескольких строк."
        ))
    for i in range(10):
        tasks.append(make_task(
            "9. FASTA и Multi-FASTA",
            "После окончания цикла Multi-FASTA сохрани последнюю запись, если current_name не None.",
            "if current_name is not None:\n    names.append(current_name)\n    sequences.append(current_sequence)",
            "Последняя запись не встретит следующий заголовок, поэтому её нужно сохранить отдельно.",
            "Проверь current_name is not None и добавь name и sequence в соответствующие списки.",
            "if current_name is not None:\n    names.append(current_name)\n    sequences.append(current_sequence)",
            "Это предотвращает потерю последней FASTA-записи."
        ))

    # Sanity: exactly 50 per category.
    by_cat = {}
    for task in tasks:
        by_cat[task["category"]] = by_cat.get(task["category"], 0) + 1

    expected = {
        "0. Основы Python": 50,
        "1. Строки": 50,
        "2. Списки": 50,
        "3. Циклы": 50,
        "4. Условия": 50,
        "5. Файлы": 50,
        "6. Функции": 50,
        "7. Словари и кортежи": 50,
        "8. DNA и последовательности": 50,
        "9. FASTA и Multi-FASTA": 50,
    }
    assert by_cat == expected, (by_cat, expected)
    return tasks

PRACTICE = build_practice_bank()


class ExamTutor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x760")
        self.minsize(950, 620)
        self.progress = self.load_progress()
        self.current_lesson = 0
        self.practice_index = 0

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        self.create_ui()
        self.show_lesson(0)

    def load_progress(self):
        try:
            return json.loads(PROGRESS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {"completed": [], "correct": 0, "attempts": 0}

    def save_progress(self):
        try:
            PROGRESS_FILE.write_text(
                json.dumps(self.progress, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception:
            pass

    def create_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text=APP_TITLE, font=("Arial", 20, "bold")).pack(side="left")
        self.progress_label = ttk.Label(top, text="")
        self.progress_label.pack(side="right")

        main = ttk.Panedwindow(self, orient="horizontal")
        main.pack(fill="both", expand=True, padx=10, pady=(0,10))

        left = ttk.Frame(main, padding=6)
        right = ttk.Frame(main, padding=6)
        main.add(left, weight=1)
        main.add(right, weight=4)

        ttk.Label(left, text="Темы", font=("Arial", 12, "bold")).pack(anchor="w", pady=(0,8))

        self.lesson_list = tk.Listbox(left, exportselection=False, font=("Arial", 10))
        self.lesson_list.pack(fill="both", expand=True)
        for lesson in LESSONS:
            self.lesson_list.insert("end", lesson["title"])
        self.lesson_list.bind("<<ListboxSelect>>", self.on_select_lesson)

        ttk.Button(left, text="Практика", command=self.show_practice).pack(fill="x", pady=(8,4))
        ttk.Button(left, text="Сбросить прогресс", command=self.reset_progress).pack(fill="x")

        self.title_label = ttk.Label(right, text="", font=("Arial", 17, "bold"))
        self.title_label.pack(anchor="w", pady=(0,8))

        text_frame = ttk.Frame(right)
        text_frame.pack(fill="both", expand=True)
        scroll = ttk.Scrollbar(text_frame)
        scroll.pack(side="right", fill="y")

        self.text = tk.Text(
            text_frame,
            wrap="word",
            yscrollcommand=scroll.set,
            font=("Consolas", 11),
            padx=14,
            pady=14
        )
        self.text.pack(fill="both", expand=True)
        scroll.config(command=self.text.yview)
        self.text.config(state="disabled")

        qa = ttk.LabelFrame(right, text="Проверка понимания", padding=10)
        qa.pack(fill="x", pady=(8,0))

        self.question_label = ttk.Label(qa, text="", wraplength=850, font=("Arial", 11, "bold"))
        self.question_label.pack(anchor="w")

        row = ttk.Frame(qa)
        row.pack(fill="x", pady=(8,0))
        self.answer_entry = ttk.Entry(row)
        self.answer_entry.pack(side="left", fill="x", expand=True)
        self.answer_entry.bind("<Return>", lambda e: self.check_answer())

        ttk.Button(row, text="Проверить", command=self.check_answer).pack(side="left", padx=(8,0))
        ttk.Button(row, text="Подсказка", command=self.show_hint).pack(side="left", padx=(8,0))
        ttk.Button(row, text="Отметить изученным", command=self.mark_completed).pack(side="left", padx=(8,0))

        self.feedback = ttk.Label(qa, text="", wraplength=850)
        self.feedback.pack(anchor="w", pady=(8,0))

        nav = ttk.Frame(right)
        nav.pack(fill="x", pady=(8,0))
        ttk.Button(nav, text="← Назад", command=self.prev_lesson).pack(side="left")
        ttk.Button(nav, text="Дальше →", command=self.next_lesson).pack(side="right")

        self.update_progress_label()

    def set_text(self, content):
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", textwrap.dedent(content).strip())
        self.text.config(state="disabled")
        self.text.yview_moveto(0)

    def show_lesson(self, index):
        self.current_lesson = max(0, min(index, len(LESSONS)-1))
        lesson = LESSONS[self.current_lesson]
        self.title_label.config(text=lesson["title"])
        self.set_text(lesson["body"])
        self.question_label.config(text=lesson["question"])
        self.answer_entry.delete(0, "end")
        self.feedback.config(text="")
        self.lesson_list.selection_clear(0, "end")
        self.lesson_list.selection_set(self.current_lesson)
        self.lesson_list.see(self.current_lesson)

    def on_select_lesson(self, event=None):
        sel = self.lesson_list.curselection()
        if sel:
            self.show_lesson(sel[0])

    def normalize(self, s):
        return " ".join(s.strip().lower().replace('"', "'").split())

    def check_answer(self):
        lesson = LESSONS[self.current_lesson]
        user = self.normalize(self.answer_entry.get())
        answers = [self.normalize(x) for x in lesson["answers"]]

        self.progress["attempts"] = self.progress.get("attempts", 0) + 1

        if user in answers:
            self.progress["correct"] = self.progress.get("correct", 0) + 1
            self.feedback.config(text="✓ Верно. " + lesson["explanation"])
        else:
            self.feedback.config(text="✗ Неверно. " + lesson["explanation"])

        self.save_progress()
        self.update_progress_label()

    def show_hint(self):
        lesson = LESSONS[self.current_lesson]
        self.feedback.config(text="Подсказка: " + lesson["hint"])

    def mark_completed(self):
        completed = set(self.progress.get("completed", []))
        completed.add(self.current_lesson)
        self.progress["completed"] = sorted(completed)
        self.save_progress()
        self.update_progress_label()
        self.feedback.config(text="✓ Тема отмечена как изученная.")

    def update_progress_label(self):
        c = len(set(self.progress.get("completed", [])))
        total = len(LESSONS)
        correct = self.progress.get("correct", 0)
        attempts = self.progress.get("attempts", 0)
        self.progress_label.config(
            text=f"Изучено: {c}/{total} | Ответы: {correct}/{attempts}"
        )

    def next_lesson(self):
        if self.current_lesson < len(LESSONS)-1:
            self.show_lesson(self.current_lesson + 1)

    def prev_lesson(self):
        if self.current_lesson > 0:
            self.show_lesson(self.current_lesson - 1)

    def reset_progress(self):
        if messagebox.askyesno("Сброс", "Удалить весь прогресс?"):
            self.progress = {"completed": [], "correct": 0, "attempts": 0}
            self.save_progress()
            self.update_progress_label()
            self.feedback.config(text="Прогресс сброшен.")

    def show_practice(self):
        win = tk.Toplevel(self)
        win.title("Практика — 500 задач")
        win.geometry("980x720")
        win.minsize(850, 600)

        categories = list(dict.fromkeys(task["category"] for task in PRACTICE))
        state = {
            "pool": [],
            "index": 0,
            "hint_level": 0,
            "correct": 0,
            "attempts": 0,
        }

        header = ttk.Frame(win, padding=10)
        header.pack(fill="x")

        ttk.Label(header, text="Практика: 50 задач на каждую тему", font=("Arial", 17, "bold")).pack(side="left")
        stats = ttk.Label(header, text="")
        stats.pack(side="right")

        controls = ttk.Frame(win, padding=(10, 0, 10, 8))
        controls.pack(fill="x")

        ttk.Label(controls, text="Тема:").pack(side="left")
        category_var = tk.StringVar(value=categories[0])
        combo = ttk.Combobox(controls, textvariable=category_var, values=categories, state="readonly", width=30)
        combo.pack(side="left", padx=8)

        random_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Перемешать задачи", variable=random_var).pack(side="left", padx=8)

        category = ttk.Label(win, text="", font=("Arial", 10, "bold"))
        category.pack()

        question = ttk.Label(win, text="", wraplength=900, font=("Arial", 12, "bold"), justify="left")
        question.pack(fill="x", padx=30, pady=16)

        ttk.Label(win, text="Твой ответ / код:").pack(anchor="w", padx=30)

        answer_box = tk.Text(win, height=8, wrap="none", font=("Consolas", 11), padx=8, pady=8)
        answer_box.pack(fill="x", padx=30, pady=(4, 8))

        hint_frame = ttk.LabelFrame(win, text="Подсказка", padding=10)
        hint_frame.pack(fill="both", expand=True, padx=30, pady=8)

        hint_text = tk.Text(hint_frame, height=8, wrap="word", font=("Consolas", 10), padx=8, pady=8)
        hint_text.pack(fill="both", expand=True)
        hint_text.config(state="disabled")

        feedback = ttk.Label(win, text="", wraplength=900, justify="left")
        feedback.pack(fill="x", padx=30, pady=(5, 8))

        def normalize_code(s):
            s = s.strip().replace("'", '"')
            lines = []
            for line in s.splitlines():
                stripped = line.strip()
                if stripped:
                    lines.append(stripped)
            return "\n".join(lines)

        def set_hint(content):
            hint_text.config(state="normal")
            hint_text.delete("1.0", "end")
            hint_text.insert("1.0", content)
            hint_text.config(state="disabled")

        def update_stats():
            stats.config(
                text=f"Задача {state['index'] + 1}/{len(state['pool'])}  |  "
                     f"Верно {state['correct']}/{state['attempts']}"
            )

        def rebuild_pool(*args):
            chosen = category_var.get()
            state["pool"] = [t for t in PRACTICE if t["category"] == chosen]
            if random_var.get():
                random.shuffle(state["pool"])
            state["index"] = 0
            state["hint_level"] = 0
            load_task()

        def load_task():
            if not state["pool"]:
                return
            task = state["pool"][state["index"]]
            state["hint_level"] = 0
            category.config(text=task["category"])
            question.config(text=task["question"])
            answer_box.delete("1.0", "end")
            set_hint("Подсказки закрыты. Сначала попробуй решить самостоятельно.")
            feedback.config(text="")
            hint_button.config(text="Открыть подсказку 1")
            update_stats()

        def check():
            task = state["pool"][state["index"]]
            got = normalize_code(answer_box.get("1.0", "end"))
            accepted = [normalize_code(a) for a in task.get("accepted", [task["answer"]])]
            state["attempts"] += 1

            if got in accepted:
                state["correct"] += 1
                feedback.config(text="✓ Верно. " + task["explanation"])
            else:
                feedback.config(
                    text="✗ Пока неверно. Это не значит, что идея обязательно плохая: "
                         "проверка сравнивает ответ с предусмотренными эталонами. "
                         "Попробуй проверить синтаксис или открыть следующую подсказку."
                )
            update_stats()

        def show_next_hint():
            task = state["pool"][state["index"]]
            state["hint_level"] = min(3, state["hint_level"] + 1)
            level = state["hint_level"]

            if level == 1:
                set_hint("УРОВЕНЬ 1 — ОСНОВНАЯ ИДЕЯ\n\n" + task["hint1"])
                hint_button.config(text="Открыть подсказку 2")
            elif level == 2:
                set_hint("УРОВЕНЬ 2 — КАК СОБРАТЬ РЕШЕНИЕ\n\n" + task["hint2"])
                hint_button.config(text="Открыть подсказку 3")
            else:
                set_hint("УРОВЕНЬ 3 — ГОТОВОЕ ЭТАЛОННОЕ РЕШЕНИЕ\n\n" + task["hint3"])
                hint_button.config(text="Подсказка 3 открыта")

        def next_task():
            if state["index"] < len(state["pool"]) - 1:
                state["index"] += 1
            else:
                state["index"] = 0
            load_task()

        def prev_task():
            if state["index"] > 0:
                state["index"] -= 1
            else:
                state["index"] = len(state["pool"]) - 1
            load_task()

        def shuffle_now():
            random.shuffle(state["pool"])
            state["index"] = 0
            load_task()

        buttons = ttk.Frame(win)
        buttons.pack(fill="x", padx=30, pady=(4, 14))

        ttk.Button(buttons, text="← Предыдущее", command=prev_task).pack(side="left")
        ttk.Button(buttons, text="Проверить", command=check).pack(side="left", padx=8)

        hint_button = ttk.Button(buttons, text="Открыть подсказку 1", command=show_next_hint)
        hint_button.pack(side="left", padx=8)

        ttk.Button(buttons, text="Перемешать сейчас", command=shuffle_now).pack(side="left", padx=8)
        ttk.Button(buttons, text="Следующее →", command=next_task).pack(side="right")

        combo.bind("<<ComboboxSelected>>", rebuild_pool)
        random_var.trace_add("write", lambda *args: rebuild_pool())
        rebuild_pool()

if __name__ == "__main__":
    app = ExamTutor()
    app.mainloop()
